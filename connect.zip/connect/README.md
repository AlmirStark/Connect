# SOBRE O CONNECT #
Connect e um aplicativo para a prefeitura de Inhapi - Alagoas, para fazer cadastro dos moradores.